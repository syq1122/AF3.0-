//
//  HeaderBaseUrl.h
//  AF3.0封装
//
//  Created by syq on 16/2/29.
//  Copyright © 2016年 lanou.syq. All rights reserved.
//

#ifndef HeaderBaseUrl_h
#define HeaderBaseUrl_h


#define uploadBaseURLStr @"http://112.80.41.109/phone/file/upload.html"

#endif /* HeaderBaseUrl_h */
